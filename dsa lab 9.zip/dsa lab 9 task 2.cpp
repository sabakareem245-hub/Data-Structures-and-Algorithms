#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
};

class Queue {
    Node *front, *rear;

public:
    Queue() {
        front = rear = NULL;
    }

    void enqueue(int val) {
        Node* temp = new Node();
        temp->data = val;
        temp->next = NULL;

        if (front == NULL) {
            front = rear = temp;
        } else {
            rear->next = temp;
            rear = temp;
        }

        cout << val << " inserted\n";
    }

    void dequeue() {
        if (front == NULL) {
            cout << "Queue is Empty!\n";
            return;
        }

        cout << front->data << " deleted\n";

        if (front == rear) {
            front = rear = NULL;
        } else {
            front = front->next;
        }
    }

    void display() {
        if (front == NULL) {
            cout << "Queue is Empty!\n";
            return;
        }

        Node* temp = front;
        cout << "Queue: ";
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    Queue q;

    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);

    q.display();

    q.dequeue();
    q.display();

    return 0;
}