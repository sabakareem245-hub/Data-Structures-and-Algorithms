#include <iostream>
using namespace std;

#define SIZE 5

class Queue {
    int arr[SIZE];
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    void enqueue(int val) {
        if (rear == SIZE - 1) {
            cout << "Queue Full\n";
            return;
        }
        if (front == -1) front = 0;
        arr[++rear] = val;
    }

    int count() {
        if (front == -1) return 0;
        return (rear - front + 1);
    }

    void display() {
        if (front == -1) {
            cout << "Queue Empty\n";
            return;
        }
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Queue q;

    q.enqueue(5);
    q.enqueue(10);
    q.enqueue(15);

    q.display();

    cout << "Total elements: " << q.count() << endl;

    return 0;
}