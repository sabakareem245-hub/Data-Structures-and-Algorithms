#include <iostream>
using namespace std;

struct Product {
    string name;
    int code;
    float price;
};

int main() {
    int n;
    cout << "Enter number of products: ";
    cin >> n;

    Product* p = new Product[n]; 

    for(int i = 0; i < n; i++) {
        cout << "\nProduct " << i+1 << endl;
        cout << "Name: ";
        cin >> p[i].name;
        cout << "Code: ";
        cin >> p[i].code;
        cout << "Price: ";
        cin >> p[i].price;
    }

    cout << "\nAll Products:\n";
    for(int i = 0; i < n; i++) {
        cout << p[i].name << " "
             << p[i].code << " "
             << p[i].price << endl;
    }

    delete[] p;  
    p = nullptr;

    return 0;
}