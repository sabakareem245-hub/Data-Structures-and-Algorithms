#include <iostream>
using namespace std;

int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int* p = arr; 

    cout << "Array elements are:" << endl;

    for(int i = 0; i < 5; i++) {
        cout << *(p + i) << " ";
    }

    return 0;
}
