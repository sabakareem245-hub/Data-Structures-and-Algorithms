#include <iostream>
using namespace std;

class Node {
public:
    string name;
    Node* next;

    Node(string n) {
        name = n;
        next = NULL;
    }
};

class EmployeeList {
public:
    Node* head = NULL;

    void add(string name) {
        Node* newNode = new Node(name);

        if (head == NULL) {
            head = newNode;
            newNode->next = head;
        } else {
            Node* temp = head;
            while (temp->next != head)
                temp = temp->next;

            temp->next = newNode;
            newNode->next = head;
        }
        cout << "Added successfully\n";
    }

    void search(string name) {
        if (head == NULL) return;

        Node* temp = head;
        do {
            if (temp->name == name) {
                cout << "Found successfully\n";
                return;
            }
            temp = temp->next;
        } while (temp != head);

        cout << "Not found\n";
    }

    void deleteEmp(string name) {
        if (head == NULL) return;

        Node *curr = head, *prev = NULL;

        if (head->name == name) {
            Node* temp = head;
            while (temp->next != head)
                temp = temp->next;

            if (head->next == head)
                head = NULL;
            else {
                temp->next = head->next;
                head = head->next;
            }

            delete curr;
            cout << "Deleted successfully\n";
            return;
        }

        do {
            prev = curr;
            curr = curr->next;

            if (curr->name == name) {
                prev->next = curr->next;
                delete curr;
                cout << "Deleted successfully\n";
                return;
            }

        } while (curr != head);

        cout << "Not found\n";
    }
};

int main() {
    EmployeeList emp;

    emp.add("Ali");
    emp.add("Sara");
    emp.add("Ahmed");

    emp.search("Sara");
    emp.deleteEmp("Ali");
}