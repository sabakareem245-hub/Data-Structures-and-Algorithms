#include <iostream>
using namespace std;

class Book {
private:
    string bookId, bookISBN;
    string bookName, bookAuthor;
    double bookPrice;

public:
    Book() {}

    Book(string id, string name, double price, string author, string isbn) {
        bookId = id;
        bookName = name;
        bookPrice = price;
        bookAuthor = author;
        bookISBN = isbn;
    }

    string getId() { return bookId; }
    string getName() { return bookName; }
    double getPrice() { return bookPrice; }
    string getAuthor() { return bookAuthor; }
    string getISBN() { return bookISBN; }

    void setData(string id, string name, double price, string author, string isbn) {
        bookId = id;
        bookName = name;
        bookPrice = price;
        bookAuthor = author;
        bookISBN = isbn;
    }

    void display() {
        cout << bookId << " " << bookName << " " << bookPrice << " "
             << bookAuthor << " " << bookISBN << endl;
    }
};

class Node {
public:
    Book data;
    Node* next;
    Node* prev;

    Node(Book b) {
        data = b;
        next = prev = NULL;
    }
};

class BookList {
public:
    Node* head = NULL;

    void addBook(string id, string name, double price, string author, string isbn) {
        Book b(id, name, price, author, isbn);
        Node* newNode = new Node(b);

        if (head == NULL) {
            head = newNode;
            head->next = head->prev = head;
        } else {
            Node* tail = head->prev;

            tail->next = newNode;
            newNode->prev = tail;
            newNode->next = head;
            head->prev = newNode;
        }
    }

    void printBooks() {
        if (head == NULL) return;

        Node* temp = head;
        do {
            temp->data.display();
            temp = temp->next;
        } while (temp != head);
    }

    void printBook(string id) {
        Node* temp = head;
        do {
            if (temp->data.getId() == id) {
                temp->data.display();
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }

    void removeBook(string id) {
        if (head == NULL) return;

        Node* temp = head;

        do {
            if (temp->data.getId() == id) {
                if (temp == head) {
                    if (head->next == head)
                        head = NULL;
                    else {
                        head->prev->next = head->next;
                        head->next->prev = head->prev;
                        head = head->next;
                    }
                } else {
                    temp->prev->next = temp->next;
                    temp->next->prev = temp->prev;
                }

                delete temp;
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }

    void updateBook(string id, string name, double price, string author, string isbn) {
        Node* temp = head;

        do {
            if (temp->data.getId() == id) {
                temp->data.setData(id, name, price, author, isbn);
                return;
            }
            temp = temp->next;
        } while (temp != head);
    }
};

int main() {
    BookList bl;

    bl.addBook("1","C++",500,"Ali","111");
    bl.addBook("2","DSA",600,"Sara","222");
    bl.addBook("3","OOP",700,"Ahmed","333");

    bl.printBooks();
}