#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int val) {
        data = val;
        next = NULL;
    }
};

class CircularLL {
public:
    Node* head = NULL;

    void insertBefore(int val) {
        Node* newNode = new Node(val);

        if (head == NULL) {
            head = newNode;
            newNode->next = head;
            return;
        }

        Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }

        temp->next = newNode;
        newNode->next = head;
        head = newNode;
    }

    void insertAfter(int val) {
        Node* newNode = new Node(val);

        if (head == NULL) {
            head = newNode;
            newNode->next = head;
            return;
        }

        Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }

        temp->next = newNode;
        newNode->next = head;
    }

    void deleteNode(int val) {
        if (head == NULL) return;

        Node* curr = head;
        Node* prev = NULL;

        if (head->data == val) {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            if (head->next == head) {
                head = NULL;
            } else {
                temp->next = head->next;
                head = head->next;
            }
            delete curr;
            return;
        }

        do {
            prev = curr;
            curr = curr->next;

            if (curr->data == val) {
                prev->next = curr->next;
                delete curr;
                return;
            }

        } while (curr != head);
    }

    void display() {
        if (head == NULL) return;

        Node* temp = head;
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != head);

        cout << "(head)\n";
    }
};

int main() {
    CircularLL list;

    list.insertBefore(10);
    list.insertBefore(5);
    list.insertAfter(20);

    list.display();

    list.deleteNode(10);
    list.display();
}