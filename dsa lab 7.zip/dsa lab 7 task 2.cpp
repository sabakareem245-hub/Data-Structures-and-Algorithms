#include <iostream>
using namespace std;
class Inventory {
public:
    int serialNum;
    int manufactYear;
    int lotNum;

    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void display() {
        cout << "Serial: " << serialNum
             << ", Year: " << manufactYear
             << ", Lot: " << lotNum << endl;
    }
};
class Node {
public:
    Inventory data;
    Node* next;

    Node(Inventory obj) {
        data = obj;
        next = NULL;
    }
};
class Stack {
    Node* top;

public:
    Stack() {
        top = NULL;
    }
    void push(Inventory obj) {
        Node* newNode = new Node(obj);
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory\n";
    }

    void pop() {
        if (top == NULL) {
            cout << "Stack empty!\n";
            return;
        }
        Node* temp = top;
        cout << "\nRemoved Part:\n";
        temp->data.display();

        top = top->next;
        delete temp;
    }
    void display() {
        if (top == NULL) {
            cout << "Stack empty!\n";
            return;
        }
        Node* temp = top;
        cout << "\nRemaining Inventory:\n";
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
    }
};

int main() {
    Stack s;
    int choice;

    do {
        cout << "\n1. Add Part\n2. Remove Part\n3. Exit\nChoice: ";
        cin >> choice;

        if (choice == 1) {
            Inventory obj;
            int sNum, year, lot;

            cout << "Enter Serial Number: ";
            cin >> sNum;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            obj.setData(sNum, year, lot);
            s.push(obj);
        }
        else if (choice == 2) {
            s.pop();
        }

    } while (choice != 3);

    s.display();

    return 0;
}