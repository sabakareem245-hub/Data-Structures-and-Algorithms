#include <iostream>
using namespace std;
class Book {
public:
    string title;
    float price;
    int edition;
    int pages;
    Book* next;

    Book(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};

class Stack {
    Book* top;

public:
    Stack() {
        top = NULL;
    }

    void push(string t, float p, int e, int pg) {
        Book* newBook = new Book(t, p, e, pg);
        newBook->next = top;
        top = newBook;
        cout << "Book pushed: " << t << endl;
    }
    void pop() {
        if (top == NULL) {
            cout << "Stack is empty!\n";
            return;
        }
        Book* temp = top;
        cout << "Book popped: " << top->title << endl;
        top = top->next;
        delete temp;
}
	
    void peek() {
        if (top == NULL) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "\nTop Book:\n";
        cout << "Title: " << top->title << endl;
        cout << "Price: " << top->price << endl;
        cout << "Edition: " << top->edition << endl;
        cout << "Pages: " << top->pages << endl;
    }

    void display() {
        if (top == NULL) {
            cout << "Stack is empty!\n";
            return;
        }
        Book* temp = top;
        cout << "\nRemaining Books:\n";
        while (temp != NULL) {
            cout << temp->title << " | " << temp->price
                 << " | " << temp->edition
                 << " | " << temp->pages << endl;
            temp = temp->next;
        }
    }
};

int main() {
    Stack s;
    s.push("Book1", 500, 1, 200);
    s.push("Book2", 600, 2, 250);
    s.push("Book3", 700, 3, 300);
    s.push("Book4", 800, 1, 150);
    s.push("Book5", 900, 2, 350);
    s.peek();
    s.pop();
    s.pop();
    s.display();
    return 0;
}