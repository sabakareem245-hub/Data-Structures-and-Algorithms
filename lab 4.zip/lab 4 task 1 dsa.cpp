#include <iostream>
using namespace std;

struct Mobile {
    string brand;
    int stock;
    float price;
    Mobile* next;
};

Mobile* head = NULL;
void addMobile(string b, int s, float p) {
    Mobile* newMobile = new Mobile();
    newMobile->brand = b;
    newMobile->stock = s;
    newMobile->price = p;
    newMobile->next = NULL;

    if(head == NULL) {
        head = newMobile;
    } else {
        Mobile* temp = head;
        while(temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newMobile;
    }
}

void deleteMobile(string b) {
    if(head == NULL) {
        cout << "Inventory is empty\n";
        return;
    }

    if(head->brand == b) {
        Mobile* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Mobile* temp = head;
    while(temp->next != NULL && temp->next->brand != b) {
        temp = temp->next;
    }

    if(temp->next == NULL) {
        cout << "Mobile not found\n";
        return;
    }

    Mobile* del = temp->next;
    temp->next = del->next;
    delete del;
}

void display() {
    Mobile* temp = head;
    while(temp != NULL) {
        cout << "Brand: " << temp->brand << endl;
        cout << "Stock: " << temp->stock << endl;
        cout << "Price: " << temp->price << endl;
        cout << "------------------\n";
        temp = temp->next;
    }
}

int main() {
    addMobile("Samsung", 10, 50000);
    addMobile("iPhone", 5, 150000);
    addMobile("Oppo", 8, 40000);

    display();

    deleteMobile("Oppo");

    cout << "\nAfter Deletion:\n";
    display();

    return 0;
}