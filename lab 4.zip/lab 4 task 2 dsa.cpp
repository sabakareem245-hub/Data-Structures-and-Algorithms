#include <iostream>
using namespace std;
struct Profile {
    string name;
    int age;
    string email;
    Profile* next;
};

Profile* head = NULL;
void createProfile(string n, int a, string e) {

    Profile* newNode = new Profile();
    newNode->name = n;
    newNode->age = a;
    newNode->email = e;
    newNode->next = NULL;
    if(head == NULL) {
        head = newNode;
    }
    else {
        Profile* temp = head;
        while(temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    cout << "Profile Created Successfully!\n";
}
void searchProfile(string n) {

    Profile* temp = head;

    while(temp != NULL) {
        if(temp->name == n) {
            cout << "\nProfile Found!\n";
            cout << "Name: " << temp->name << endl;
            cout << "Age: " << temp->age << endl;
            cout << "Email: " << temp->email << endl;
            return;
        }
        temp = temp->next;
    }

    cout << "Profile Not Found!\n";
}

void updateProfile(string n) {

    Profile* temp = head;

    while(temp != NULL) {
        if(temp->name == n) {
            cout << "Enter New Age: ";
            cin >> temp->age;
            cout << "Enter New Email: ";
            cin >> temp->email;
            cout << "Profile Updated Successfully!\n";
            return;
        }
        temp = temp->next;
    }

    cout << "Profile Not Found!\n";
}
void deleteProfile(string n) {

    if(head == NULL) {
        cout << "No Profiles Available!\n";
        return;
    }

    if(head->name == n) {
        Profile* temp = head;
        head = head->next;
        delete temp;
        cout << "Profile Deleted!\n";
        return;
    }

    Profile* temp = head;

    while(temp->next != NULL && temp->next->name != n) {
        temp = temp->next;
    }

    if(temp->next == NULL) {
        cout << "Profile Not Found!\n";
        return;
    }

    Profile* del = temp->next;
    temp->next = del->next;
    delete del;

    cout << "Profile Deleted Successfully!\n";
}

void viewAllProfiles() {

    if(head == NULL) {
        cout << "No Profiles to Display!\n";
        return;
    }

    Profile* temp = head;

    cout << "\n--- All Profiles ---\n";

    while(temp != NULL) {
        cout << "Name: " << temp->name << endl;
        cout << "Age: " << temp->age << endl;
        cout << "Email: " << temp->email << endl;
        cout << "--------------------\n";
        temp = temp->next;
    }
}


int main() {

    int choice;
    string name, email;
    int age;

    do {
        cout << "\n1. Create Profile\n";
        cout << "2. Update Profile\n";
        cout << "3. Delete Profile\n";
        cout << "4. Search Profile\n";
        cout << "5. View All Profiles\n";
        cout << "6. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch(choice) {

            case 1:
                cout << "Enter Name: ";
                cin >> name;
                cout << "Enter Age: ";
                cin >> age;
                cout << "Enter Email: ";
                cin >> email;
                createProfile(name, age, email);
                break;

            case 2:
                cout << "Enter Name to Update: ";
                cin >> name;
                updateProfile(name);
                break;

            case 3:
                cout << "Enter Name to Delete: ";
                cin >> name;
                deleteProfile(name);
                break;

            case 4:
                cout << "Enter Name to Search: ";
                cin >> name;
                searchProfile(name);
                break;

            case 5:
                viewAllProfiles();
                break;

            case 6:
                cout << "Exiting Program...\n";
                break;

            default:
                cout << "Invalid Choice!\n";
        }

    } while(choice != 6);

    return 0;
}