#include<iostream>
using namespace std;

int linearSearch(int arr[], int size, int x, int index)
{
    if(index >= size)
        return -1;

    if(arr[index] == x)
        return index;

    return linearSearch(arr, size, x, index + 1);
}

int main()
{
    int arr[] = {5,10,15,20,25};

    int result = linearSearch(arr,5,20,0);

    if(result == -1)
        cout<<"Element not found";
    else
        cout<<"Element found at index "<<result;

    return 0;
}