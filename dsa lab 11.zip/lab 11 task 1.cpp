#include<iostream>
using namespace std;

int main()
{
    int tickets[10] = {
        13579,26791,26792,33445,55555,
        62483,77777,79422,85647,93121
    };

    int winningNumber;
    bool found = false;

    cout<<"Enter this week's winning 5-digit number: ";
    cin>>winningNumber;

    for(int i=0; i<10; i++)
    {
        if(tickets[i] == winningNumber)
        {
            found = true;
            break;
        }
    }

    if(found)
        cout<<"Congratulations! One of your tickets is a winner.";
    else
        cout<<"Invalid number. No ticket matched.";

    return 0;
}