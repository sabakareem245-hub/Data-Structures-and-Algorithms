#include<iostream>
using namespace std;

int binarySearch(int arr[], int left, int right, int x)
{
    if(left <= right)
    {
        int mid = (left + right) / 2;

        if(arr[mid] == x)
            return mid;

        if(arr[mid] > x)
            return binarySearch(arr, left, mid - 1, x);

        return binarySearch(arr, mid + 1, right, x);
    }

    return -1;
}

int main()
{
    int arr[] = {2,3,4,10,40};
    int size = 5;
    int x = 10;

    int result = binarySearch(arr,0,size-1,x);

    if(result == -1)
        cout<<"Element not found";
    else
        cout<<"Element found at index "<<result;

    return 0;
}