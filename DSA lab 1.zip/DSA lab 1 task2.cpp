#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Enter array size: ";
    cin >> n;

    int arr[n];

    cout << "Enter elements:\n";
    for(int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int index, newValue;

    cout << "Enter index to update: ";
    cin >> index;

    cout << "Enter new value: ";
    cin >> newValue;

    if(index >= 0 && index < n) {
        arr[index] = newValue;
    } else {
        cout << "Invalid index!";
        return 0;
    }

    cout << "Updated array:\n";
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
